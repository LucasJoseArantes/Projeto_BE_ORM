package br.edu.iftm.leilao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeilaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
